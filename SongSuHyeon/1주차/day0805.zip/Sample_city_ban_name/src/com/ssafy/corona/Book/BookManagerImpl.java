package com.ssafy.corona.Book;

import java.util.ArrayList;
import java.util.List;

public class BookManagerImpl implements BookManager{
	List<Book> bookList = new ArrayList<Book>();
	static BookManagerImpl bookManagerImpl = new BookManagerImpl();
	
	// 60. 싱글톤 : 생성자 접근 제한자 private로 변경
	private BookManagerImpl() {
		// 파일에서 읽어서 bookList에 저장하기
		bookList.add(new Book("홍길동전", 60000));
		bookList.add(new Book("심청전", 30000));
		bookList.add(new Book("슈퍼맨", 25000));
		bookList.add(new Book("스파이더맨", 90000));
		bookList.add(new Book("아이언맨", 40000));
	}
	
	public static BookManagerImpl getInstance() {
		return bookManagerImpl;
	}
	
	public List<Book> search() {
		
		
		return bookList;

	}
	
	@Override
	// 매개변수로 받은 Book객체와 동일한 객체가 bookList에 존재하면 찾아서 리턴해주는 메서드
	public Book search(Book book) {
		for (Book b : bookList) {
			if(book.equals(b)) {
				return b;
			}
		}
		return null;
	}
}

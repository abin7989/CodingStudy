package com.ssafy.corona.Book;

import java.util.List;

public interface BookManager {
	Book search(Book b);
	default List<Book> search() {
		return null;
	}
	
}

package com.ssafy.corona.app;

import java.util.*;

import com.ssafy.corona.Book.Book;
import com.ssafy.corona.Book.BookManager;
import com.ssafy.corona.Book.BookManagerImpl;
import com.ssafy.corona.virus.*;

public class MainTest {
	public static void main(String[] args) {

		// 10.질병관리 문제 //
		//
		// 아래 11~13번 주석을 해제하여
		// "정상 출력 예" 와 같이 출력될 수 있도록
		// 코드들을 디버깅 하세요!
		//
		System.out.println("10.질병관리(코로나,메르스) =================================");
		VirusMgr vmgr = new VirusMgrImpl();
		System.out.println();

		// 네비게이션 단축키 F3 : 변수, 메서드, 클래스 정의부로 정의한 코드로 화면 이동 = Ctrl + 클릭
		// Alt + 왼족/오른쪽 방향키 : 이전/이후 봤던 화면으로 이동
		// <- 주석 해제 후 작성 : start ////////////////////////////////
		System.out.println("11.코로나19 등록");
		// 정상 출력 예:
		// 11.코로나19 등록
		// 코로나19: 등록된 바이러스입니다.
		try {
			vmgr.add(new Mers("메르스15", 2, 1.5));
			vmgr.add(new Corona("코로나19", 3, 2));
			vmgr.add(new Corona("코로나19", 2, 2));
		} catch (DuplicatedException e) {
			System.out.println(e.getMessage());
		}
		System.out.println();

		System.out.println("12.바이러스 전체검색");
		// 정상 출력 예:
		// 12.바이러스 전체검색
		// 메르스15 2 1.5
		// 코로나19 3 2
		Virus[] virus = vmgr.search();
		for (Virus v : virus) {
			System.out.println(v.toString());
		}
		System.out.println();

		System.out.println("13.코로나15 조회");
		// 정상 출력 예:
		// 13.코로나15 조회
		// 코로나15: 미등록 바이러스입니다.
		try {
			Virus v = vmgr.search("코로나15");
			System.out.println(v);
		} catch (NotFoundException e) {
			System.out.println(e.getMessage());
		}
		System.out.println();
		// <- 주석 해제 후 작성 : end /////////////////////////////////

		// 60. BookManagerImpl : 싱글톤 패턴 적용
		BookManager bookManagerImpl = BookManagerImpl.getInstance();

		Book book = bookManagerImpl.search(new Book("아이언맨", 40000));
		System.out.println(book);

		System.out.println("================================================");
		// 61. bookManagerImpl에 저장된 책을 가격순으로 출력
		List<Book> bookList = bookManagerImpl.search();

		Collections.sort(bookList);

		for (Book b : bookList) {
			System.out.println(b);
		}

		// 62. 이름의 역순으로 정렬하는 외부 비교기 작성
		System.out.println("================================================");
		Collections.sort(bookList, new Comparator<Book>() {
			@Override
			public int compare(Book o1, Book o2) {
				// 오름차순 o1 - o2
				return o1.getName().compareTo(o2.getName());
			}
		});

		for (Book b : bookList) {
			System.out.println(b);
		}

		// 62. 이름의 역순으로 내림차순 정렬하는 외부 비교기 작성
		System.out.println("================================================");
		Collections.sort(bookList, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// 오름차순 o1 - o2
				return -o1.getName().compareTo(o2.getName());
			}
		});

		for (Book b : bookList) {
			System.out.println(b);
		}

		/*Collections.sort(bookList, new Comparator<Book>() {
			@Override
			public int compare(Book o1, Book o2) {
				return -o1.getName().compareTo(o2.getName());
			}
		});*/
		// 63. 외부비교기를 jdk8에서 나온 Lambda 식 표현으로 작성
		Collections.sort(bookList, (Book o1, Book o2) -> 
			-o1.getName().compareTo(o2.getName())
		);

		for (Book b : bookList) {
			System.out.println(b);
		}

	}

}

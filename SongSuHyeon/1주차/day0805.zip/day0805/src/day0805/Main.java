package day0805;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	static int S, P;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		S = Integer.parseInt(st.nextToken());
		P = Integer.parseInt(st.nextToken());

		String s = br.readLine();
		StringTokenizer st2 = new StringTokenizer(br.readLine(), " ");
		String cnt = "";
		for (int i = 0; i < 4; i++) {
			cnt += st2.nextToken();
		}

		int[] cmp = new int[4];
		String[] sum = new String[S + 1];
		sum[0] = "0";
		for (int i = 0; i < S; i++) {
			if (s.charAt(i) == 'A') {
				cmp[0]++;
			} else if (s.charAt(i) == 'C') {
				cmp[1]++;
			} else if (s.charAt(i) == 'G') {
				cmp[2]++;
			} else if (s.charAt(i) == 'T') {
				cmp[3]++;
			} else {
				continue;
			}

			String tmp = "";
			for (int j = 0; j < 4; j++) {
				tmp += String.valueOf(cmp[j]);
			}

			sum[i + 1] = tmp;
		}

		int res = 0;
		boolean check = true;
		for (int i = 0, j = P; i <= S - P; i++, j++) {
			String tmp = String.format("%04d", Integer.valueOf(sum[j]) - Integer.valueOf(sum[i]));
			for (int k = 0; k < 4; k++) {
				if (cnt.charAt(k) > tmp.charAt(k)) {
					check = false;
					break;
				} 
			}
			
			if(check) {
				res++;
			}
		}
		System.out.println(res);
	} // end of main
} // end of class

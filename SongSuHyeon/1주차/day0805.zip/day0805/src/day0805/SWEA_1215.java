package day0805;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class SWEA_1215 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		for (int test_case = 1; test_case <= 1; test_case++) {
			int N = Integer.valueOf(br.readLine());

			char[][] arr = new char[8][];
			for (int i = 0; i < 8; i++) {
				arr[i] = br.readLine().toCharArray();
			}

			System.out.println(Arrays.deepToString(arr));

			int res =0 ;
			// 가로 탐색
			for (int i = 0; i < 8; i++) {
				for (int j = 0; j <= 8-N; j++) {
					boolean check = true;
					for (int start = i, end = N+j-1; start < 8 && end >= 0; start++, end--) {
						if(arr[i][start] != arr[i][end]) check = false;
					}
					if(check) res++;
				}
			}

			// 세로 탐색
			for (int i = 0; i < 8; i++) {
				for (int j = 0; j <= 8-N; j++) {
					boolean check = true;
					for (int start = i, end = N+j-1; start < 8 && end >= 0; start++, end--) {
						if(arr[start][i] != arr[end][i]) check = false;
					}
					if(check) res++;
				}
			}
			
			System.out.println("#" + test_case+" " +res);
		}
	}
}

package day0805;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Solution {
	public static void main(String[] args) {
		List<int[]> list = new ArrayList<>();
		list.add(new int[] {1,2});
		list.add(new int[] {5,2});
		list.add(new int[] {6,1});
		list.add(new int[] {3,4});
		list.add(new int[] {5,3});

		for (int i = 0; i < list.size(); i++) {
			System.out.println(Arrays.toString(list.get(i)));
		}

		System.out.println("====================================");
		Collections.sort(list, new Comparator<int[]>() {
			@Override
			public int compare(int[] o1, int[] o2) {
				// TODO Auto-generated method stub
				return o1[1] - o2[1];
			}
		});

		for (int i = 0; i < list.size(); i++) {
			System.out.println(Arrays.toString(list.get(i)));
		}
		
		System.out.println("====================================");
		Collections.sort(list, new Comparator<int[]>() {
			@Override
			public int compare(int[] o1, int[] o2) {
				if(o1[1] == o2[1]) {
					return -o1[0] + o2[0];
				}
				return o1[1] - o2[1];
			}
		});

		for (int i = 0; i < list.size(); i++) {
			System.out.println(Arrays.toString(list.get(i)));
		}
		
		System.out.println("====================================");
	
	}
}
